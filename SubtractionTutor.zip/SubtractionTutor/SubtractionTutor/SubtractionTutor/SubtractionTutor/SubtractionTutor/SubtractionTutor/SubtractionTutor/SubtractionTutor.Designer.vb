﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SubtractionTutor
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.userAnsTextBox = New System.Windows.Forms.TextBox()
        Me.num1Label = New System.Windows.Forms.Label()
        Me.num2Label = New System.Windows.Forms.Label()
        Me.verifyButton = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.keyLabel = New System.Windows.Forms.Label()
        Me.resetButton = New System.Windows.Forms.Button()
        Me.resultLabel = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(44, 48)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(100, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "First Number"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(170, 63)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(28, 37)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "-"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(225, 48)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(124, 20)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Second Number"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(360, 65)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(37, 37)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "="
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(430, 48)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(105, 20)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Enter Answer"
        '
        'userAnsTextBox
        '
        Me.userAnsTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.userAnsTextBox.Location = New System.Drawing.Point(435, 71)
        Me.userAnsTextBox.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.userAnsTextBox.Name = "userAnsTextBox"
        Me.userAnsTextBox.Size = New System.Drawing.Size(92, 35)
        Me.userAnsTextBox.TabIndex = 7
        '
        'num1Label
        '
        Me.num1Label.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.num1Label.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.num1Label.Location = New System.Drawing.Point(48, 69)
        Me.num1Label.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.num1Label.Name = "num1Label"
        Me.num1Label.Size = New System.Drawing.Size(94, 34)
        Me.num1Label.TabIndex = 8
        '
        'num2Label
        '
        Me.num2Label.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.num2Label.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.num2Label.Location = New System.Drawing.Point(230, 68)
        Me.num2Label.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.num2Label.Name = "num2Label"
        Me.num2Label.Size = New System.Drawing.Size(94, 34)
        Me.num2Label.TabIndex = 9
        '
        'verifyButton
        '
        Me.verifyButton.Location = New System.Drawing.Point(406, 134)
        Me.verifyButton.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.verifyButton.Name = "verifyButton"
        Me.verifyButton.Size = New System.Drawing.Size(123, 40)
        Me.verifyButton.TabIndex = 10
        Me.verifyButton.Text = "Verify"
        Me.verifyButton.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(57, 145)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(39, 20)
        Me.Label8.TabIndex = 11
        Me.Label8.Text = "Key:"
        '
        'keyLabel
        '
        Me.keyLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.keyLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.keyLabel.Location = New System.Drawing.Point(48, 169)
        Me.keyLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.keyLabel.Name = "keyLabel"
        Me.keyLabel.Size = New System.Drawing.Size(94, 35)
        Me.keyLabel.TabIndex = 12
        '
        'resetButton
        '
        Me.resetButton.Location = New System.Drawing.Point(406, 183)
        Me.resetButton.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.resetButton.Name = "resetButton"
        Me.resetButton.Size = New System.Drawing.Size(123, 40)
        Me.resetButton.TabIndex = 13
        Me.resetButton.Text = "Reset"
        Me.resetButton.UseVisualStyleBackColor = True
        '
        'resultLabel
        '
        Me.resultLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.resultLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.resultLabel.Location = New System.Drawing.Point(178, 169)
        Me.resultLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.resultLabel.Name = "resultLabel"
        Me.resultLabel.Size = New System.Drawing.Size(172, 35)
        Me.resultLabel.TabIndex = 14
        '
        'SubtractionTutor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(588, 266)
        Me.Controls.Add(Me.resultLabel)
        Me.Controls.Add(Me.resetButton)
        Me.Controls.Add(Me.keyLabel)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.verifyButton)
        Me.Controls.Add(Me.num2Label)
        Me.Controls.Add(Me.num1Label)
        Me.Controls.Add(Me.userAnsTextBox)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "SubtractionTutor"
        Me.Text = "Subtraction Tutor"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents userAnsTextBox As System.Windows.Forms.TextBox
    Friend WithEvents num1Label As System.Windows.Forms.Label
    Friend WithEvents num2Label As System.Windows.Forms.Label
    Friend WithEvents verifyButton As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents keyLabel As System.Windows.Forms.Label
    Friend WithEvents resetButton As System.Windows.Forms.Button
    Friend WithEvents resultLabel As System.Windows.Forms.Label

End Class
